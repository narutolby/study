IDL(Interface Description Language)

interface Node {
  // NodeType
  const unsigned short      ELEMENT_NODE       = 1;
  const unsigned short      ATTRIBUTE_NODE     = 2;
  const unsigned short      TEXT_NODE          = 3;
  const unsigned short      CDATA_SECTION_NODE = 4;
  const unsigned short      ENTITY_REFERENCE_NODE = 5;
  const unsigned short      ENTITY_NODE        = 6;
  const unsigned short      PROCESSING_INSTRUCTION_NODE = 7;
  const unsigned short      COMMENT_NODE       = 8;
  const unsigned short      DOCUMENT_NODE      = 9;
  const unsigned short      DOCUMENT_TYPE_NODE = 10;
  const unsigned short      DOCUMENT_FRAGMENT_NODE = 11;
  const unsigned short      NOTATION_NODE      = 12;

  readonly attribute  DOMString            nodeName;
           attribute  DOMString            nodeValue; // raises(DOMException) on setting, raises(DOMException) on retrieval
  readonly attribute  unsigned short       nodeType;
  readonly attribute  Node                 parentNode;
  readonly attribute  NodeList             childNodes;
  readonly attribute  Node                 firstChild;
  readonly attribute  Node                 lastChild;
  readonly attribute  Node                 previousSibling;
  readonly attribute  Node                 nextSibling;
  readonly attribute  NamedNodeMap         attributes;
  readonly attribute  Document             ownerDocument;
  Node                      insertBefore(in Node newChild, in Node refChild) raises(DOMException);
  Node                      replaceChild(in Node newChild, in Node oldChild) raises(DOMException);
  Node                      removeChild(in Node oldChild) raises(DOMException);
  Node                      appendChild(in Node newChild) raises(DOMException);
  boolean                   hasChildNodes();
  Node                      cloneNode(in boolean deep);
  void                      normalize(); // Modified in DOM Level 2
};


interface Document : Node {
  readonly attribute  DocumentType         doctype;
  readonly attribute  DOMImplementation    implementation;
  readonly attribute  Element              documentElement;

  Element                   createElement(in DOMString tagName) raises(DOMException);
  DocumentFragment          createDocumentFragment();
  Text                      createTextNode(in DOMString data);
  Comment                   createComment(in DOMString data);
  CDATASection              createCDATASection(in DOMString data) raises(DOMException);
  ProcessingInstruction     createProcessingInstruction(in DOMString target, in DOMString data) raises(DOMException);
  Attr                      createAttribute(in DOMString name) raises(DOMException);
  EntityReference           createEntityReference(in DOMString name) raises(DOMException);
  NodeList                  getElementsByTagName(in DOMString tagname);
};


interface HTMLDocument : Document {
           attribute  DOMString            title;
  readonly attribute  DOMString            referrer;
  readonly attribute  DOMString            domain;
  readonly attribute  DOMString            URL;
           attribute  HTMLElement          body;
  readonly attribute  HTMLCollection       images;
  readonly attribute  HTMLCollection       applets;
  readonly attribute  HTMLCollection       links;
  readonly attribute  HTMLCollection       forms;
  readonly attribute  HTMLCollection       anchors;
           attribute  DOMString            cookie;

  void                      open();
  void                      close();
  void                      write(in DOMString text);
  void                      writeln(in DOMString text);
  Element                   getElementById(in DOMString elementId);
  NodeList                  getElementsByName(in DOMString elementName);
};


interface Element : Node {
  readonly attribute  DOMString            tagName;
  
  DOMString                 getAttribute(in DOMString name);
  void                      setAttribute(in DOMString name, in DOMString value) raises(DOMException);
  void                      removeAttribute(in DOMString name) raises(DOMException);
  Attr                      getAttributeNode(in DOMString name);
  Attr                      setAttributeNode(in Attr newAttr) raises(DOMException);
  Attr                      removeAttributeNode(in Attr oldAttr) raises(DOMException);
  NodeList                  getElementsByTagName(in DOMString name);
  void                      normalize();
};


interface HTMLElement : Element {
           attribute  DOMString            id;
           attribute  DOMString            title;
           attribute  DOMString            lang;
           attribute  DOMString            dir;
           attribute  DOMString            className;
};


interface CharacterData : Node {
           attribute  DOMString            data; // raises(DOMException) on setting, raises(DOMException) on retrieval
  readonly attribute  unsigned long        length;

  DOMString                 substringData(in unsigned long offset, in unsigned long count) raises(DOMException);
  void                      appendData(in DOMString arg) raises(DOMException);
  void                      insertData(in unsigned long offset, in DOMString arg) raises(DOMException);
  void                      deleteData(in unsigned long offset, in unsigned long count) raises(DOMException);
  void                      replaceData(in unsigned long offset, in unsigned long count, in DOMString arg) raises(DOMException);
};


interface Text : CharacterData {
  Text                      splitText(in unsigned long offset) raises(DOMException);
};


interface Comment : CharacterData {
};


interface CDATASection : Text {
};


interface DocumentType : Node {
  readonly attribute  DOMString            name;
  readonly attribute  NamedNodeMap         entities;
  readonly attribute  NamedNodeMap         notations;
};


interface DocumentFragment : Node {
};


interface Attr : Node {
  readonly attribute  DOMString            name;
  readonly attribute  boolean              specified;
           attribute  DOMString            value;
};


